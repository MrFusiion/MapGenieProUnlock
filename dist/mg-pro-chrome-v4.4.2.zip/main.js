(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
const waitForDomLoaded = require("../shared/waitForDomLoaded");
const { isList, isMap, isGuide } = require("../page/site");


function error(message) {
    window.postMessage({ type: "mg:error", message }, "*");
}

function get_status(sendResponse) {
    waitForDomLoaded().then(() => {
        sendResponse({
            is_list:    isList(),
            is_map:     isMap(),
            is_guide:   isGuide(),
        });
    });
    return true;
}

function reload_window(sendResponse) {
    window.location.reload();
    sendResponse();
    return true;
}

function export_mapdata(sendResponse) {
    let gameid = sessionStorage.getItem("gameid");
    let userid = sessionStorage.getItem("userid");
    if (!gameid || !userid) return;

    let mapData = JSON.parse(window.localStorage.getItem(`mg:game_${gameid}:user_${userid}`) || null);
    if (!mapData) return error("No map data found");

    let blob = new Blob([JSON.stringify({
        gameid: gameid,
        userid: userid,
        mapdata: mapData,
    })], { type: "text/plain;charset=utf-8" });
    let url = URL.createObjectURL(blob);

    let a = document.createElement("a");
    a.href = url;
    a.download = `mg:game_${gameid}:user_${userid}_${new Date().toISOString()}.json`;
    document.body.appendChild(a);
    a.click();

    setTimeout(function () {
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }, 0);

    return false;
}

function import_mapdata(sendResponse) {
    let gameid = sessionStorage.getItem("gameid");
    let userid = sessionStorage.getItem("userid");
    if (!gameid || !userid) return;

    var filebrowser = document.createElement("input");
    filebrowser.type = "file";
    filebrowser.click();

    filebrowser.onchange = () => {
        let file = filebrowser.files[0];
        if (!file) return;

        var reader = new FileReader();
        reader.onload = function (e) {
            let data;
            try {
                data = JSON.parse(e.target.result || null) || {};
            } catch (e) {
                return error(`Invalid JSON file: ${e}`);
            }
            if (typeof data !== "object") return error("json has no valid data");
            if (data.gameid !== gameid) return error("json file is not for this game");
            if (data.userid !== userid) return error("json file is not for this user");
            if (!data.mapdata) return error("json file does not contain map data");

            //TODO validate data;
            window.localStorage.setItem(`mg:game_${gameid}:user_${userid}`, JSON.stringify(data.mapdata));
            window.dispatchEvent(new CustomEvent("mg:mapdata_changed"));
            filebrowser.remove();
        }
        reader.readAsText(file);
    };

    return false;
}

function clear_mapdata(sendResponse) {
    let game_title = sessionStorage.getItem("game_title");
    let ans = confirm(`Are you sure you want to clear your map data for game ${game_title}?`);
    if (!ans) return;

    let gameid = sessionStorage.getItem("gameid");
    let userid = sessionStorage.getItem("userid");
    if (!gameid || !userid) return;

    window.localStorage.removeItem(`mg:game_${gameid}:user_${userid}`);
    window.dispatchEvent(new CustomEvent("mg:mapdata_changed"));
    return false
}

module.exports = { get_status, reload_window, export_mapdata, import_mapdata, clear_mapdata };
},{"../page/site":6,"../shared/waitForDomLoaded":8}],2:[function(require,module,exports){
const waitForDomLoaded = require("../shared/waitForDomLoaded");
const { isList, isMap, isGuide } = require("../page/site");
const { getSettings } = require("../shared/settings");

const { injectCode, injectStyle } = require('./inject');
const { getScript } = require('./observer');


//Find data script and unparent it from the dom
let p_dataScript = Promise.race([
    getScript({ startsWith: "window.mapUrls" }),
    getScript({ startsWith: "window.mapUrl" })
]).then(script => {
    parent = script.parentNode;
    script.remove();
    return { script, parent };
})

//Find map script and unparent it from the dom
let p_mapScript = getScript({ src: "map.js" }).then(script => {
    parent = script.parentNode;
    script.remove();
    return { script, parent };
})


getSettings().then((settings) => {
    waitForDomLoaded().then(() => {
        if (settings.extension_enabled && (isList() || isMap() || isGuide())) {

            //Hide non-pro elements
            for (let selector of Object.values([
                "#blobby-left", ".upgrade", ".progress-buttons ~ .inset",               // map
                "#button-upgrade", "p ~ h5 ~ p ~ h4 ~ blockquote", "p ~ h5 ~ p ~ h4"    // guide
            ])) {
                for (let element of document.querySelectorAll(selector))
                    element.style.display = "none";
            }

            injectStyle("page.css"); // src/page/page.css
            injectCode("page.js"); //src/page folder will be compiled into one script called page.js
        }
    });

    p_dataScript.then(({ script, parent }) => {
        if (script) {
            parent.append(script)
            if (settings.extension_enabled) {
                window.sessionStorage.setItem("mg:config:presets_allways_enabled", JSON.stringify(settings.presets_allways_enabled || false));
                const dataScript = document.createElement("script");
                dataScript.src = chrome.runtime.getURL("data.js");
                parent.append(dataScript);
                return new Promise(resolve => {
                    dataScript.onload = function () {
                        resolve();
                    };
                });
            }
        };
    }).then(() => {
        p_mapScript.then(({ script, parent }) => {
            if (!script) return;
            parent.append(script);
        }).catch(console.error);
    }).catch(console.error);
});


//Handle requests from popup
chrome.runtime.onMessage.addListener(function (request, _, sendResponse) {
    const action = require("./handlers")[request.action];
    if (action)
        return action(sendResponse);
    end

    console.warn("Extension can't handle request ", request);
    return false;
});
},{"../page/site":6,"../shared/settings":7,"../shared/waitForDomLoaded":8,"./handlers":1,"./inject":3,"./observer":4}],3:[function(require,module,exports){
function getURL(url) {
    return (url.startsWith("https://") || url.startsWith("http://")) && url || chrome.runtime.getURL(url);
}


function injectCode(src, defered = false, module = false) {
    return new Promise(resolve => {
        let script = document.createElement("script");
        script.src = getURL(src);
        script.onload = function () { this.remove(); resolve(); };
        script.defer = defered;
        script.type = module && "module" || "application/javascript";
        (document.head||document).append(script);
    });
}

function injectStyle(href) {
    return new Promise(resolve => {
        let style = document.createElement("link");
        style.rel = "stylesheet";
        style.href = getURL(href);
        style.onload = function () { resolve(); };
        (document.head||document).append(style);
    });
}


module.exports = { injectCode, injectStyle };
},{}],4:[function(require,module,exports){
function getScript({ startsWith, src }) {
    return new Promise((resolve, reject) => {
        function clear() {
            document.removeEventListener("DOMContentLoaded", loaded);
            observer.disconnect();
        }

        function loaded() {
            clear();
        }

        const observer = new MutationObserver(function (mutations_list) {
            mutations_list.forEach(function (mutation) {
                mutation.addedNodes.forEach(function (added_node) {
                    if (added_node.nodeName === "SCRIPT") {
                        if (startsWith && added_node.innerText.startsWith(startsWith)) {
                            resolve(added_node);
                            clear();
                        } else if (src && added_node.src.match(src)) {
                            resolve(added_node);
                            clear();
                        }
                    }
                });
            });
        });
        document.addEventListener("DOMContentLoaded", loaded);

        observer.observe(document, { childList: true, subtree: true });
    });
}


module.exports = { getScript };
},{}],5:[function(require,module,exports){
module.exports = [
    {
        "type": "checkbox",
        "default": true,
        "name": "extension_enabled",
        "label": "Extension Enabled",
        "tooltip": "Enable/Disable the extension."
    },
    {
        "type": "checkbox",
        "default": false,
        "name": "presets_allways_enabled",
        "label": "Allways enable presets",
        "tooltip": "This option enables presets on all maps. Will not allways work when the extension is to slow to load."
    }
];
},{}],6:[function(require,module,exports){
module.exports = {
    isList() {
        return window.location.href === "https://mapgenie.io/";
    },

    isMap() {
        return !!document.querySelector(".map > #app > #map");
    },

    isGuide() {
        return !!document.querySelector(".guide > #app #sticky-map");
    }
}
},{}],7:[function(require,module,exports){
const options = Object.freeze(require("../options"));

//Gets all options
function getOptions() {
    return options;
}

//Gets stored extension settings
function getSettings() {
    return new Promise(resolve => {
        chrome.storage.sync.get(["config"], (result) => {
            let config = Object.assign({}, ...getOptions().map((option) => ({ [option.name]: option.default })), result.config || {});

            //Cleanup faulty keys
            for (let key in config) {
                if (key.match(/^\d+$/)) {
                    delete config[key];
                }
            }

            setSettings(config);
            resolve(config);
        });
    });
}

//Sets stored extension settings
function setSettings(settings) {
    chrome.storage.sync.set({ config: settings });
}


module.exports = { getOptions, getSettings, setSettings };
},{"../options":5}],8:[function(require,module,exports){
module.exports = async function() {
    return new Promise((res, rej) => {
        if (document.readyState === "complete") {
            res();
        } else {
            let handle = setInterval(() => {
                if (document.readyState === "complete") {
                    clearInterval(handle);
                    res();
                }
            }, 100);
        }
    });
}
},{}]},{},[2]);
