(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
class ApiDeleteHandler {
    constructor(store, storage) {
        this.hasDfltPreset = store.state.user.presets.length > 0;
        this.storage = storage;
        this.et = new EventTarget();
    }

    presets(_, id) {
        this.storage.updateData(data => {
            let index = data.presets_order.indexOf(id);
            if (index !== -1) data.presets_order.splice(index, 1);

            if (this.hasDfltPreset && data.presets_order.length == 1) data.presets_order = [];
            delete data.presets[id];
            return data;
        });
    }

    locations(_, id) {
        this.storage.updateData(data => {
            if (data.locations[id]) {
                delete data.locations[id];
                this.storage.local.foundLocationsCount -= 1;
            }
            return data;
        });
        this._dispatch("locations", { id });
    }

    categories(_, id) {
        this.storage.updateData(data => {
            delete data.categories[id];
            return data;
        });
        this._dispatch("categories", { id });
    }

    _dispatch(name, data) {
        this.et.dispatchEvent(Object.assign(new Event(name), data));
    }

    on(name, f) {
        this.et.addEventListener(name, f)
    }

    off(name, f) {
        this.et.removeEventListener(name, f);
    }
}

module.exports = ApiDeleteHandler;
},{}],2:[function(require,module,exports){
const ApiPutHandler = require("../api/put");
const ApiPostHandler = require("../api/post");
const ApiDeleteHandler = require("../api/delete");

class ApiHandler {
    constructor(store, storage) {
        this.put = new ApiPutHandler(store, storage);
        this.post = new ApiPostHandler(store, storage);
        this.delete = new ApiDeleteHandler(store, storage);
    }
}

module.exports = ApiHandler;
},{"../api/delete":1,"../api/post":3,"../api/put":4}],3:[function(require,module,exports){
class ApiPostHandler {
    constructor(store, storage) {
        this.hasDfltPreset = store.state.user.presets.length > 0;
        this.storage = storage;
        this.et = new EventTarget();
    }

    presets(_, __, postData) {
        this.storage.updateData(data => {
            postData.id = 0;
            for (let i in data.presets) {
                if (postData.id != i) break;
                postData.id++;
            }

            const preset = Object.assign({}, postData);
            delete preset.ordering;

            data.presets[postData.id] = preset;

            if (data.presets_order.length == 0 && this.hasDfltPreset) data.presets_order.push(-1);
            data.presets_order.push(postData.id);

            return data;
        });
        this._dispatch("presets", { postData });

        return { data: postData };
    }

    presets_reorder(_, __, postData) {
        this.storage.updateData(data => {
            data.presets_order = postData.ordering;
            return data;
        });
        this._dispatch("presets_reorder", { ordering: postData.ordering });
    }

    categories(_, id, postData) {
        id = postData?.category || id;
        this.storage.updateData(data => {
            data.categories[id] = true;
            return data;
        });
        this._dispatch("categories", { id });
    }

    _dispatch(name, data) {
        this.et.dispatchEvent(Object.assign(new Event(name), data));
    }

    on(name, f) {
        this.et.addEventListener(name, f)
    }

    off(name, f) {
        this.et.removeEventListener(name, f);
    }
}

module.exports = ApiPostHandler;
},{}],4:[function(require,module,exports){
class ApiPutHandler {
    constructor(_, storage) {
        this.storage = storage;
        this.et = new EventTarget();
    }

    locations(_, id) {
        this.storage.updateData(data => {
            if (!data.locations[id]) {
                data.locations[id] = true;
                this.storage.local.foundLocationsCount += 1;
            }
            return data;
        });
        this._dispatch("locations", { id });
    }

    _dispatch(name, data) {
        this.et.dispatchEvent(Object.assign(new Event(name), data));
    }

    on(name, f) {
        this.et.addEventListener(name, f)
    }

    off(name, f) {
        this.et.removeEventListener(name, f);
    }
}

module.exports = ApiPutHandler;
},{}],5:[function(require,module,exports){
function deepCopy(obj) {
    if (typeof obj === "object") {
        let newObj = obj instanceof Array ? [] : {};
        for (let key in obj) {
            if (typeof obj[key] === "object") {
                newObj[key] = deepCopy(obj[key]);
            } else {
                newObj[key] = obj[key];
            }
        }
        return newObj;
    }
    return obj;
}


function objectSet(obj, newObj) {
    for (let key in obj) {
        if (!newObj.hasOwnProperty(key)) {
            delete obj[key];
        }
    }
    for (let key in newObj) {
        obj[key] = deepCopy(newObj[key]);
    }
    return obj;
}


function deepAsign(value, newValue) {
    if (typeof value === "object" && typeof newValue === "object") {
        let o = newValue instanceof Array ? [] : {};
        for (let key in value) {
            o[key] = value[key];
        }
        for (let key in newValue) {
            o[key] = deepAsign(value && value[key], newValue && newValue[key]);
        }
        return o;
    }
    return deepCopy(typeof newValue === "undefined" ? value : newValue);
}


function objMinimize(data, defaultData) {
    if (typeof data === "object") {
        let o = data instanceof Array ? [] : {}, c = 0;
        for (let key in data) {
            let val = objMinimize(data && data[key], defaultData && defaultData[key]);
            if (val !== undefined) {
                o[key] = val;
                c++;
            }
        }
        return c > 0 > 0 ? o : undefined;
    }
    if (typeof data !== "undefined" && data !== defaultData) {
        return data;
    }
}


function objDiff(obj1, obj2) {
    if (typeof obj1 === "object" && typeof obj2 === "object"
        && (obj1 instanceof Array == obj2 instanceof Array))
    {
        let o = obj1 instanceof Array ? [] : {};
        let len1 = Object.keys(obj1).length;
        let len2 = Object.keys(obj2).length;
        for (var i = 0; i < Math.min(len1, len2); i++) {
            
        }
    } else if (obj1 !== obj2) {
        return { 1: obj1, 2: obj2 };
    }
}


module.exports = {
    deepCopy,
    objectSet,
    deepAsign,
    objMinimize,
    objDiff
};
},{}],6:[function(require,module,exports){
class Filter {
    constructor(object, handlers) {
        this.handlers = handlers;

        for (let funcName in handlers) {
            object[funcName] = this._filter(object[funcName], funcName);
        }
    }

    //Needs to be overwritten by child classes
    _filter(f) {
        return f; 
    }
}

class MGApiFilter extends Filter {
    static Filtered = Symbol("filtered");

    constructor(axios, handlers) {
        //Check if its allready filtered if it is 
        if (axios[MGApiFilter.Filtered]) throw new Error("MGApiFilter already filtered this object!", axios);
        axios[MGApiFilter.Filterered] = true;

        super(axios, handlers);
        this.axios = axios;
    }

    _getHandler(handlerName, key) {
        const name = key.replace("/", "_");
        const subHandlers = this.handlers[handlerName];
        return subHandlers?.[name].bind(subHandlers);
    }

    _handle(handlerName, key, argsArray) {
        const handler = this._getHandler(handlerName, key);
        if (handler) {
            const data = handler(...argsArray);
            return { data };
        }
        return null;
    }

    _filter(f, handlerName) {
        return (...args) => {
            const [str, data] = args;
            const key = str.match(/\/api\/v1\/user\/((\/?[A-Za-z]+)+)\/?/)?.[1];
            if (key) {
                let id = parseInt((str.match(/(\d+)$/) || { 1: -1 })[1]);
                const result = this._handle(handlerName, key, [key, id, data, str]);
                if (result) {
                    return Promise.resolve(result.data || data);
                }
            }
            return f(...args);
        }
    }
}


class MGStorageFilter extends Filter {
    constructor(localStorage, handlers) {
        super(localStorage.__proto__, handlers);
        this.localStorage = localStorage;
    }

    _getHandler(handlerName, key) {
        const subHandlers = this.handlers[handlerName];
        if (subHandlers) {
            for (let name of Object.getOwnPropertyNames(Object.getPrototypeOf(subHandlers))) {
                if (!name.match(/^(_.+|constructor)$/)) {
                    const handler = subHandlers[name];
                    if (key.match(name)) {
                        return handler.bind(subHandlers);
                    }
                }
            }
        }
        return null;
    }

    _filter(f, handlerName) {
        return (key, value) => {
            const handler = this._getHandler(handlerName, key);
            const cancel = handler && handler(key, value) || false;
            if (cancel) {
                return value;
            }
            return f.call(this.localStorage, key, value);
        }
    }
}


module.exports = {
    MGApiFilter,
    MGStorageFilter
}
},{}],7:[function(require,module,exports){
const { MGApiFilter } = require("./filters");
const { MGMap } = require("./map/main");


class MGGuide {
    constructor(window) {
        this.map;
        this.document = window.document;

        window.isPro = true;

        this.mapFrame = document.querySelector("iframe[src*='https://mapgenie.io']");
        this.mapFrame.addEventListener("load", () => {
            this._setupMap().then(this.load.bind(this));
        });

        this.checkboxes = {};
        for (var checkbox of this.document.querySelectorAll(".check")) {
            this.checkboxes[checkbox.getAttribute("data-location-id")] = checkbox;
        }

        this.apiFilter = new MGApiFilter(window.axios, {
            put: {
                locations: (_, id, __, str) => {
                    if (!this.map.store.state.map.locationsById[id]) {
                        this.map.window.axios.put(str);
                    }
                }
            },

            delete: {
                locations: (_, id, __, str) => {
                    if (this.map.store.state.map.locationsById[id]) {
                        this.map.window.axios.delete(str);
                    }
                }
            }
        });
    }

    async _setupMap() {
        let mapWindow = this.mapFrame.contentWindow;
        
        mapWindow.map = mapWindow.map || {}
        await new Promise((resolve) => {
            let handle = setInterval(() => {
                if (mapWindow.map._loaded) {
                    clearInterval(handle);

                    if (mapWindow.Loaded) return;
                    mapWindow.Loaded = true;
                    this.map = new MGMap(mapWindow, true);

                    // Search for locations associated with the guide
                    let tables = this.document.querySelectorAll("table");
                    for (let table of tables) {
                        let row = table && table.querySelector("tbody > tr");
                        let checkboxes = row && row.querySelectorAll(".check") || [];
                        let categories = [];
                        for (let checkbox of checkboxes) {
                            let id = checkbox.getAttribute("data-location-id");
                            let catId = this.map.getCategoryId(id);
                            if (catId) categories.push(catId);
                        }
                        if (categories.length > 0) {
                            this.map.categories = categories;
                            break;
                        }
                    }

                    this.map.on("mark-locations", ({ id, marked }) => {
                        this._markInTable(id, marked||false); 
                    });

                    resolve();
                }
            }, 100);
        });
    }

    _checkboxSetChecked(checkbox, checked) {
        if (checkbox) {
            checkbox.checked = checked;
        }
    }

    _markInTable(id, found = true) {
        let checkbox = this.checkboxes[id];
        this._checkboxSetChecked(checkbox, found);
    }

    load() {
        if (!this.map) return Promise.resolve();

        return this.map.load().then(() => {
            this.map.showAll();

            // Mark all found locations in table
            let foundLocations = this.map.store.state.user.foundLocations;
            for (var checkbox of this.document.querySelectorAll(".check")) {
                let id = checkbox.getAttribute("data-location-id");
                this._checkboxSetChecked(checkbox, foundLocations[id]);
            }
        });
    }
}


module.exports = function () {
    if (!window.mg_pro_unlocker_loaded) {
        window.toastr.error("MapGeniePro Unlock:\nExtension was to slow set some options, please try again.");
    }

    let mgGuide = new MGGuide(window);
    mgGuide._setupMap().then(() => {
        mgGuide.load().then(() => {
            console.log("Guide hijacker loaded");
        });

        // Listen for page focus
        this.document.addEventListener('visibilitychange', () => {
            if (this.document.visibilityState == "visible") {
                mgGuide.load();
            }
        });

        window.addEventListener("mg:mapdata_changed", mgGuide.load.bind(mgGuide));
    });

    window.mgGuide = mgGuide;
}
},{"./filters":6,"./map/main":11}],8:[function(require,module,exports){
const { isList, isMap, isGuide } = require("./site");
const mapInit = require("./map");
const guideInit = require("./guide");
const listInit = require("./list");


window.addEventListener("message", (e) => {
    let data = e.data;
    if (data.type === "mg:error") {
        if (toastr) {
            toastr.error(data.message);
        } else {
            console.error(data.message);
        }
    }
});


$(function () {
    if (isList()) {
        listInit();
    } else if (isMap()) {
        mapInit();
    } else if (isGuide()) {
        guideInit();
    }
});
},{"./guide":7,"./list":9,"./map":10,"./site":19}],9:[function(require,module,exports){
module.exports = function () {
    // Add a searchbar to the page.
    const $gameList = $("#games-list-container > .games");

    function filterGameList(text) {
        $gameList.children().each((i, game) => {
            let gameName = $(game).find(".card-body > h4").text();
            if (gameName.toLowerCase().includes(text.toLowerCase())) {
                $(game).show();
            } else {
                $(game).hide();
            }
        });
    }

    let $gamesListContainer = $("#games-list-container");

    let $datalist = $("<datalist>").attr("id", "game-list");
    for (let game of $gamesListContainer.find(".games").children()) {
        let $option = $("option");
        $option.val($(game).find(".card-body > h4").text());
        $datalist.append($option);
    }
    $datalist.appendTo(document.body);

    let $gameSearchFrom = $(`<div class="game-search-container">
            <div class="game-search-form">
                <input list="games-list" type="search" placeholder="Search.." name="mg:game_search">
                <!--<button><i class="fa fa-search"></i></button>-->
            </div>
        </div>`);
    let $input = $gameSearchFrom.find("input");
    $gameSearchFrom.insertBefore($gamesListContainer);

    $input.on("keyup", () => {
        filterGameList($input.val());
    });
}
},{}],10:[function(require,module,exports){
const { MGMap } = require("./main");


module.exports = function () {
    if (!window.mg_pro_unlocker_loaded && !window.config.presetsEnabled) {
        this.window.toastr.error("MapGeniePro Unlock:\nExtension was to slow to enable presets, please try again.");
    }

    let mgMap = new MGMap(window);
    mgMap.init().then(() => {
        console.log("Map hijacker loaded");

        // Listen for page focus
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState == "visible") {
                mgMap.load();
            }
        });

        window.addEventListener("mg:mapdata_changed", mgMap.load.bind(mgMap));
    });

    window.mgMap = mgMap;
}
},{"./main":11}],11:[function(require,module,exports){
const MGMapStore = require("./store");
const MGMapStorage = require("./storage");
const { MGStorageFilter, MGApiFilter } = require("../filters");
const PopupObserver = require("./popupObserver");

//Handlers
const ApiHandler = require("../api");
const StorageHandler = require("./storageHandler");

//UI
const MarkControls = require("./ui/markControls");
const TotalProgress = require("./ui/totalProgress");
const ToggleFound = require("./ui/toggleFound");


class MGMapMarkEvent extends Event {
    constructor(type, id, marked) {
        super(type);
        this.id = id;
        this.marked = marked;
    }
}


function toggle(dict, key) {
    if (dict[key]) {
        delete dict[key];
        return false;
    } else {
        dict[key] = true;
        return true;
    }
}


class MGMap {
    #eventTarget = new EventTarget();
    #categories; #isMini; #storage;

    constructor(window, mini = false) {
        if (!window.user) { throw "User is not loggedin!"; }

        this.#isMini = mini;
        this.window = window;
        this.document = this.window.document;
        this.id = this.window.mapData.map.id;
        this._popup = null;

        sessionStorage.setItem("game_title", window.game.title);
        sessionStorage.setItem("gameid", window.game.id);
        sessionStorage.setItem("userid", window.user.id);

        this.window.user.hasPro = true;
        this.window.mapData.maxMarkedLocations = 9e10;

        this.#storage = new MGMapStorage(this.window);
        this.store = new MGMapStore(this.window, this.#storage);

        const storageHandler = new StorageHandler(this.#storage);
        this.storageFilter = new MGStorageFilter(this.window.localStorage, storageHandler);

        const apiHandler = new ApiHandler(this.store, this.#storage);
        this.apiFilter = new MGApiFilter(this.window.axios, apiHandler);

        apiHandler.put.on("locations", ({ id }) => {
            this.store.markLocation(id, true);
            this._update();
            this.#eventTarget.dispatchEvent(new MGMapMarkEvent(`mark-locations`, id, true));
        });
        
        apiHandler.delete.on("locations", ({ id }) => {
            this.store.markLocation(id, false);
            this._update();
            this.#eventTarget.dispatchEvent(new MGMapMarkEvent(`mark-locations`, id, false));
        });

        apiHandler.put.on("categories", ({ id }) => {
            this.#eventTarget.dispatchEvent(new MGMapMarkEvent(`mark-categories`, id, true));
        })

        apiHandler.delete.on("categories", ({ id }) => {
            this.#eventTarget.dispatchEvent(new MGMapMarkEvent(`mark-categories`, id, false));
        })

        if (mini) {
            $(`<button class="btn btn-outline-secondary" style="margin-left: 5px;">Show All</button>`)
                .click(this.showAll.bind(this)).appendTo($(this.window.document).find("#mini-header .d-flex"));
            return;
        }

        //Create total progress element on the right
        this.totalProgress = new TotalProgress(this.window);

        //Overwrite togglefound element provided by mapgenie because it doesn't show the correct count
        this.toggleFound = new ToggleFound(this.window);

        //Observe if popup gets added and listen when clicked
        this.popupObserver = new PopupObserver(this.store);
        this.popupObserver.click((e) => {
            const id = e.locId;
            this.#storage.updateData((data) => {
                const found = toggle(data.locations, id);
                this.store.markLocation(id, found);
                this.#storage.local.foundLocationsCount += found ? 1 : -1;
                return data;
            })
            this._update();
        });
        this.popupObserver.observe(this.window);

        //Add marker controls at the right corner of the map
        // 1 markAll: Marks all visible markers
        // 2 unmarkAll: Unmarks all visible markers
        this.markControls = new MarkControls(this.window);
        this.markControls.click((found) => {
            //Confirm if the user want's to unmark or mark all visible markers
            let ans = confirm(`Are you sure you want to ${!found && "un" || ""}mark all visible markers on the map?`);
            if (!ans) return;

            //Count how many markers are mark or unmarked
            this.#storage.updateData(data => {
                for (let loc of this.store.state.map.locations) {
                    if (loc.category.visible) {
                        if (found && !data.locations[loc.id]) {
                            this.#storage.local.foundLocationsCount++;
                            data.locations[loc.id] = true;
                        } else if (!found && data.locations[loc.id]) {
                            this.#storage.local.foundLocationsCount--;
                            delete data.locations[loc.id];
                        }
                        this.store.markLocation(loc.id, found);
                    }
                }
                return data;
            });
            this._update();
        });
    }

    set categories(categories) {
        if (typeof (categories) === "string") {
            this.#categories = { [categories]: true };
        } else if (typeof (categories) === "object") {
            this.#categories = Object.assign({},
                ...categories.map((category) => ({ [category]: true })));
        } else {
            this.#categories = undefined;
        }
    }

    showAll() {
        if (this.#isMini) {
            this.store.hideAllCategories();
            if (this.#categories) {
                this.store.showCategories(this.#categories);
            } else {
                this.store.showAllCategories();
            }
        }
    }

    _update() {
        //We don't have to update the UI if the map is in mini mode
        if (this.#isMini) return;

        const count = this.#storage.local.foundLocationsCount;
        const total = this.window.mapData.totalLocations
            || (this.window.mapData.totalLocations = Object.keys(this.store.state.map.locations).length);
        
        
        //Update totalProress and togglefound counter
        this.totalProgress.update(count, total);
        this.toggleFound.update(count);

        //Update mapManager
        this.window.mapManager.updateFoundLocationsStyle?.();

        //Update popup
        const popup = this.popupObserver.currentPopup;
        this.popupObserver.currentPopup?.update(this.store.isMarked(popup?.locId));
    }

    getCategoryId(id) {
        let loc = this.store.state.map.locationsById[id];
        return loc && loc.category_id || undefined;
    }

    setRememberCategories(value) {
        let $label = $(this.window.document).find("label[for='remember-categories-checkbox']");
        let $div = $label.closest(".checkbox-wrapper")
        let image = this.window.getComputedStyle($label.get(0), ":after").webkitMaskImage;
        let checked = image != "none" && image != "";
        if ((value || false) != checked) {
            $div.click();
        }
    }

    init() {
        //Get initial locations and categories
        const visibleLocations = this.window.visibleLocations;
        const visibleCategories = this.window.visibleCategories;

        //Do react update
        this.store.toggleCategories([]); // Force react update
        this.store.updateFoundLocationsCount(0); // Force react update

        //Load map data then restore initial locations and categories
        return this.load().then(() => {
            if (visibleLocations || visibleCategories) {
                this.window.mapManager.applyFilter({
                    locationIds: visibleLocations && Object.keys(visibleLocations || {}).map(parseInt),
                    categoryIds: visibleCategories && Object.keys(visibleCategories || {}).map(parseInt)
                })
            }
        });
    }

    load() {
        return new Promise((resolve) => {
            //Retrieve localstorage data
            this.#storage.load();

            //Wait until map is loaded the resolve
            if (this.window.map.loaded())
                resolve();
            else {
                let handle = setInterval(() => {
                    if (this.window.map.loaded()) {
                        clearInterval(handle);
                        resolve();
                    }
                }, 50);
            }
        }).then(() => {
            //Unmark all non-stored locations
            this.store.markLocations(false);

            //Mark all stored locations
            for (let loc in this.#storage.data.locations) {
                this.store.markLocation(loc, true);
            }

            //Only do this if the map is not in mini mode
            if (!this.#isMini) {

                //Untrack all non-stored categories
                this.store.trackCategories(false);

                //Track all stored categores
                for (let cat in this.#storage.data.categories) {
                    this.store.trackCategory(cat, true);
                }


                //If remember categories is true load last visible categories
                if (this.#storage.settings.remember_categories) {
                    this.#storage.autosave = false;
                    let visibleCategories = Object.assign({}, this.#storage.data.visible_categories);
                    this.store.hideAllCategories();
                    this.setRememberCategories(true);
                    this.store.showCategories(visibleCategories);
                    this.#storage.autosave = true;
                } else {
                    this.setRememberCategories(false);
                }

                //Remove non-stored presets except for the default one;
                let curPresets = this.store.state.user.presets;
                let presets = Object.values(this.#storage.data.presets);
                if (curPresets[0]) {
                    for (let preset of curPresets) {
                        this.store.removePreset(preset.id);
                    }
                    this.store.addPreset(curPresets[0]);
                }

                //Add stored presets
                for (let preset of presets) {
                    this.store.addPreset(preset);
                }

                //Order presets
                if (this.#storage.data.presets_order.length > 0) {
                    this.store.reorderPresets(this.#storage.data.presets_order);
                }
            }

            //Update map
            this._update();
        });
    }

    on(type, callback) {
        return this.#eventTarget.addEventListener(type, callback);
    }

    off(type) {
        return this.#eventTarget.removeEventListener(type, callback);
    }
}


module.exports = { MGMap }
},{"../api":2,"../filters":6,"./popupObserver":12,"./storage":13,"./storageHandler":14,"./store":15,"./ui/markControls":16,"./ui/toggleFound":17,"./ui/totalProgress":18}],12:[function(require,module,exports){
class Popup {
    constructor(node, locId) {
        this.node = node;

        const label = node.querySelector("label[for='found-checkbox']");
        const button = label?.parentNode;
        
        if (!button) {
            return;
        }

        this.button = button.cloneNode(true);
        $(this.button).insertAfter(button);

        button.style.display = "none";

        this.input = this.button.querySelector("input[type='checkbox']");
        this.locId = locId;
        this.found = this.input.checked;
    }

    click(f) {
        return this.button?.addEventListener("click", f);
    }

    update(marked) { 
        if (this.input) {
            this.input.checked = marked;
        }
    }
}


class PopupObserver extends MutationObserver {
    constructor(store) {
        super((mutations_list) => {
            mutations_list.forEach(mutation => {
                mutation.removedNodes.forEach((node) => {
                    if (node.classList.contains("mapboxgl-popup")) {
                        this.currentPopup = null;
                    }
                });

                mutation.addedNodes.forEach((node) => {
                    if (node.classList.contains("mapboxgl-popup")) {
                        this.currentPopup = new Popup(node, store.state.map.selectedLocation?.id);
                        this.currentPopup.click(() => {
                            const e = new Event("click");
                            e.locId = this.currentPopup.locId;
                            this.et.dispatchEvent(e);
                        });
                    }
                });
            });      
        });

        this.et = new EventTarget();
        this.currentPopup = null;
    }

    click(f) {
        this.et.addEventListener("click", f);
    }

    observe(window) {
        super.observe.apply(this, [window.document.querySelector(".mapboxgl-map"), { childList: true }]);
    }
}

module.exports = PopupObserver;
},{}],13:[function(require,module,exports){
const { deepCopy, deepAsign, objectSet, objMinimize } = require("../common");

function findOldMapData(gameid) {
    let key = `mg:data:game_${gameid}`;
    let data = window.localStorage.getItem(key);
    if (data) {
        window.localStorage.removeItem(key);
        return JSON.parse(data);
    }
    return null;
}

class MGMapStorage {
    #key; #eventTarget;

    static default = {
        data: {
            locations: {},
            categories: {},
            presets: {},
            presets_order: [],
            visible_categories: {},
            notes: {},
        },

        settings: {
            remember_categories: false,
        }
    }

    constructor(window, autosave = true) {
        let gameid = window.game.id;
        let userid = window.user.id;
        this.#key = `mg:game_${gameid}:user_${userid}`;
        this.#eventTarget = new EventTarget();
        this.localStorage = window.localStorage;
        this.autosave = autosave;
        this.mapData = {
            map_id: window.mapData.map.id,
            locationsById: window.store.getState().map.locationsById
        }
    }

    get key() {
        return this.#key;
    }

    updateData(f) {
        let newData = f(deepCopy(this.data));
        if (typeof newData === "undefined") throw new Error("updateData: update function did not return a value!");
        objectSet(this.data, newData);
        this.saveCheck();
        return this;
    }

    updateSettings(f) {
        let newSettings = f(deepCopy(this.settings));
        if (typeof newSettings === "undefined") throw new Error("updateSettings: update function did not return a value!");
        objectSet(this.settings, newSettings);
        this.saveCheck();
        return this;
    }

    update(f) {
        let newData = f(deepCopy({ data: this.data, settings: this.settings }));
        if (typeof newData === "undefined") throw new Error("update: update function did not return a value!");
        objectSet(this.data, newData.data || {});
        objectSet(this.settings, newData.settings || {});
        this.saveCheck();
        return this;
    }

    load() {
        let storage = JSON.parse(this.localStorage.getItem(this.#key) || null) || {};
        
        // find old map data from previous version v3.0.0
        let oldData = findOldMapData(this.mapData.map_id);
        let data = deepAsign(MGMapStorage.default.data, Object.assign({}, oldData || {}, storage.data || {}));
        let settings = deepAsign(MGMapStorage.default.settings, storage.settings || {});

        this.data = objectSet(this.data || {}, data);
        this.settings = objectSet(this.settings || {}, settings)

        if (oldData) {
            this.save();
        }

        let c = 0;
        let mapId = this.mapData.map_id;
        let locationsById = this.mapData.locationsById;
        for (let locId in this.data.locations) {
            let loc = locationsById[locId];
            if (loc && loc.map_id == mapId) {
                c++;
            }
        }

        this.local = {
            foundLocationsCount: c,
        }
    }

    save() {
        let data = objMinimize(this.data, MGMapStorage.default.data);
        let settings = objMinimize(this.settings, MGMapStorage.default.settings);
        if (data || settings) {
            this.localStorage.setItem(this.#key, JSON.stringify({ data, settings }));
        } else {
            this.localStorage.removeItem(this.#key);
        }
    }

    saveCheck() {
        if (this.autosave) this.save();
    }

    on(type, f) {
        this.#eventTarget.addEventListener(type, f);
    }

    off(type, f) {
        this.#eventTarget.removeEventListener(type, f);
    }
}

module.exports = MGMapStorage;
},{"../common":5}],14:[function(require,module,exports){
class SetHandler {
    constructor(storage) {
        this.storage = storage;
    }

    visible_categories(key) {
        let id = key.match(/(\d+)$/)[1];
        this.storage.updateData(data => {
            data.visible_categories[id] = true;
            return data;
        });
        return true;
    }

    remember_categories() {
        this.storage.updateSettings(settings => {
            settings.remember_categories = true;
            return settings;
        });
        return true;
    }
}

class RemoveHandler {
    constructor(storage) {
        this.storage = storage;
    }

    visible_categories(key) {
        let id = key.match(/(\d+)$/)[1];
        this.storage.updateData(data => {
            delete data.visible_categories[id];
            return data;
        });
        return true;
    }

    remember_categories() {
        this.storage.update(({ settings, data }) => {
            settings.remember_categories = false;
            for (let key in data.visible_categories) delete data.visible_categories[key];
            return { settings, data };
        });
        return true;
    }
}

class StorageHandler {
    constructor(storage) {
        this.setItem = new SetHandler(storage);
        this.removeItem = new RemoveHandler(storage);
    }
}

module.exports = StorageHandler;
},{}],15:[function(require,module,exports){
class MGMapStore {
    #map; #gameid;

    constructor(window, storage) {
        this.store = window.store;
        this.#map = window.map;
        this.#gameid = window.game.id;

        // create wrapper for getState so we can overide some values
        let getState = window.store.getState;
        window.store.getState = () => {
            let state = getState();
            if (storage.local && storage.data) {
                state.user.foundLocationsCount = storage.local.foundLocationsCount;
                state.user.foundLocations = storage.data.locations;
                state.user.trackedCategories = Object.keys(storage.data.categories).map((key) => parseInt(key));
            }
            return state;
        }
    }

    *locations(categories = undefined) {
        let locations = this.state.map.locations;
        for (let i in locations) {
            let loc = locations[i];
            if (!categories || categories.find(val => val == loc.category_id)) {
                yield loc;
            }
        }
    }

    *categories(locations = undefined, visible = undefined) {
        let categories = this.state.map.categories;
        let wantCategories = locations && new Set(locations.map((loc) => loc.category_id));
        for (let i in categories) {
            let cat = categories[i];
            if (!locations || wantCategories.has(cat.id)) {
                if (visible === undefined || cat.visible == visible) {
                    yield cat;
                }
            }
        }
    }

    get state() {
        return this.store.getState();
    }

    _dispatch(type, meta = {}) {
        this.store.dispatch({ type, meta });
    }

    isMarked(id) {
        return this.state.user.foundLocations[id] ? true : false;
    }

    markLocation(id, found = true) {
        id = parseInt(id);
        this.#map.setFeatureState({ source: "locations-data", id }, { found });
        if (this.#gameid === 80) this.#map.setFeatureState({ source: "circle-locations-data", id }, { found });
    }

    toggleLocation(id) {
        if (this.isMarked(id)) {
            this.markLocation(id, false);
        } else {
            this.markLocation(id, true);
        }
    }

    markLocations(found = true, options = { categories: undefined, locations: undefined }) {
        let { categories, locations } = options;
        for (let loc of this.locations(options.categories)) {
            let correctCategory = !categories || categories.find(val => val == loc.category_id);
            let correctLocation = !locations || locations.find(val => val == loc.id);
            if (correctCategory && correctLocation) {
                this.markLocation(loc.id, found);;
            }
        }
    }

    showSpecificLocations(locations = [], categories = []) {
        this._dispatch("HIVE:MAP:SHOW_SPECIFIC_LOCATIONS", {
            locationIds: locations.map(id => parseInt(id)),
            categoryIds: categories.map(id => parseInt(id))
        })
    }

    setSelectedLocation(locationId) {
        this._dispatch("HIVE:MAP:SET_SELECTED_LOCATION", { locationId });
    }

    trackCategory(id, track = true) {
        let type = track && "HIVE:USER:ADD_TRACKED_CATEGORY" || "HIVE:USER:REMOVE_TRACKED_CATEGORY";
        this._dispatch(type, { categoryId: parseInt(id) });
    }

    trackCategories(track = true, categories) {
        for (let cat in (categories || this.state.categories)) {
            this.trackCategory(cat, track);
        }
    }

    showAllCategories() {
        this._dispatch("HIVE:MAP:SHOW_ALL_CATEGORIES");
    }

    hideAllCategories() {
        this._dispatch("HIVE:MAP:HIDE_ALL_CATEGORIES");
    }

    showCategories(visibilities) {
        this._dispatch("HIVE:MAP:SET_CATEGORIES_VISIBILITY", { visibilities });
    }

    toggleCategories(categoryIds) {
        this._dispatch("HIVE:MAP:TOGGLE_CATEGORIES", { categoryIds });
    }

    setSelectedCategory(categoryId) {
        this._dispatch("HIVE:MAP:SET_SELECTED_CATEGORY", { selectedCategory: categoryId })
    }

    updateFoundLocationsCount(count = 0) {
        this._dispatch("HIVE:USER:UPDATE_FOUND_LOCATIONS_COUNT", { count })
    }

    addPreset(preset) {
        this._dispatch("HIVE:USER:ADD_PRESET", { preset });
    }

    removePreset(presetId) {
        this._dispatch("HIVE:USER:DELETE_PRESET", { presetId });
    }

    reorderPresets(ordering) {
        let presets = [];
        for (let preset of this.state.user.presets) {
            presets[ordering.indexOf(preset.id)] = preset;
        }
        this._dispatch("HIVE:USER:REORDER_PRESETS", { presets });
    }

    applyPreset(preset, additive) {
        this._dispatch("HIVE:MAP:APPLY_PRESET", { preset, additive });
    }

    unapplyPreset(preset) {
        this._dispatch("HIVE:MAP:UNAPPLY_PRESET", { preset });
    }

    setActivePresets(activePresets) {
        this._dispatch("HIVE:MAP:SET_ACTIVE_PRESETS", { activePresets });
    }

    showNotes(visible) {
        this._dispatch("HIVE:USER:SHOW_NOTES", { visible });
    }
}

module.exports = MGMapStore;
},{}],16:[function(require,module,exports){
class MarkControls {
    constructor(window) {
        this.$element = $(`<div class="mapboxgl-ctrl mapboxgl-ctrl-group">
            <button class="mg-mark-all-control" type="button" title="Mark all" aria-label="Mark all" aria-disabled="false">
                <span class="mapboxgl-ctrl-icon ion-md-add-circle" aria-hidden="true"></span>
            </button>
            <button class="mg-unmark-all-control" type="button" title="UnMark all" aria-label="Unmark all" aria-disabled="false">
                <span class="mapboxgl-ctrl-icon ion-md-close-circle" aria-hidden="true"></span>
            </button>
        </div>`);

        this.$markAll = this.$element.find(".mg-mark-all-control");
        this.$unmarkAll = this.$element.find(".mg-unmark-all-control");

        this.$element.insertAfter($(window.document).find("#add-note-control"));
    }

    click(f) {
        this.$markAll.click(f.bind(f, true));
        this.$unmarkAll.click(f.bind(f, false));
    }
}

module.exports = MarkControls;
},{}],17:[function(require,module,exports){
class ToggleFound {
    constructor(window) {
        $(window.document).find("#toggle-found").hide();
        this.$element = $(`<span id="toggle-found" class="button-toggle"><i class="icon ui-icon-show-hide"></i>Found Locations (0)</span>`)
            .insertAfter($(window.document).find("#toggle-found"))
            .click(() => {
                this.$element.toggleClass("disabled");
                window.mapManager.setFoundLocationsShown(!this.$element.hasClass("disabled"));
            });
    }

    update(count) {
        this.$element.html(`
            <i class="icon ui-icon-show-hide"></i>
            Found Locations(${count})
        `);
    }
}

module.exports = ToggleFound;
},{}],18:[function(require,module,exports){
class TotalProgress {
    constructor(window) {
        this.$element = $(`<div class="progress-item-wrapper">
            <div class="progress-item" id="total-progress" style="margin-right: 5%;">
                <span class="icon">0.00%</span>
                <span class="title"></span>
                <span class="counter">0/0</span>
                <div class="progress-bar-container">
                    <div class="progress-bar" role="progressbar" style="width: 0%;"></div>
                </div>
            </div>
        </div>
        <hr>`);

        this.$item = this.$element.find(".progress-item");
        
        this.$icon = this.$element.find(".icon").get(0);
        this.$counter = this.$element.find(".counter").get(0);
        this.$progressBar = this.$element.find(".progress-bar").get(0);

        this.$element.insertBefore($(window.document).find("#user-panel > div:first-of-type .category-progress"));
    }

    click(f) {
        return this.$item.click(f);
    }
    
    update(count, total) {
        let percent = count / total * 100;
        this.$icon.textContent = `${percent.toFixed(2)}%`;
        this.$counter.textContent = `${count} / ${total}`;
        this.$progressBar.style.width = `${percent}%`;
    }
}

module.exports = TotalProgress;
},{}],19:[function(require,module,exports){
module.exports = {
    isList() {
        return window.location.href === "https://mapgenie.io/";
    },

    isMap() {
        return !!document.querySelector(".map > #app > #map");
    },

    isGuide() {
        return !!document.querySelector(".guide > #app #sticky-map");
    }
}
},{}]},{},[8]);
