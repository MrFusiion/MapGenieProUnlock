(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
module.exports = [
    {
        "type": "checkbox",
        "default": true,
        "name": "extension_enabled",
        "label": "Extension Enabled",
        "tooltip": "Enable/Disable the extension."
    },
    {
        "type": "checkbox",
        "default": false,
        "name": "presets_allways_enabled",
        "label": "Allways enable presets",
        "tooltip": "This option enables presets on all maps. Will not allways work when the extension is to slow to load."
    }
];
},{}],2:[function(require,module,exports){
const { getOptions, getSettings, setSettings } = require("../shared/settings");

let Settings;
let $buttons = [];
let $optionElements = [];
let $statusElements = [];

function send(action, data, options = { all: false }) {
    let queryOptions = options.all && {} || { active: true, currentWindow: true };
    return new Promise((resolve) => {
        chrome.tabs.query(queryOptions, tabs => {
            Promise.all(tabs.map(tab => {
                return new Promise((resolve, reject) => {
                    chrome.tabs.sendMessage(tab.id, { action, data }, (res) => {
                        var lastError = chrome.runtime.lastError;
                        if (lastError) {
                            reject(lastError);
                        } else {
                            resolve(res);
                        }
                    });
                }).catch((err) => {
                    return new Error(err);
                });
            })).then((results) => {
                if (queryOptions.active && queryOptions.currentWindow) {
                    resolve(results[0]);
                }
                resolve(results);
            })
        });
    });
}

function setStatus(status) {
    let activeCount = 0;
    for (let $statusElement of $statusElements) {
        if (status?.[`is_${$statusElement.attr("id")}`]) {
            activeCount++; 
            $statusElement.addClass("active");
        } else {
            $statusElement.removeClass("active");
        }
    }
    for (let $btn of $buttons) {
        $btn.prop("disabled", activeCount < 1);
    }
}

function assignButton(selector, action) {
    $buttons.push($(selector).click(() => {
        send(action);
        window.close();
    }));
}

function addCheckboxOption(name, label, checked, tooltip="") {
    const $optionElement = $(`<div class="option" type="checkbox">
        <div class="toggle-button-cover">
            <div class="button r">
                <input class="checkbox" type="checkbox" id=${name}>
                <div class="knobs"></div>
                <div class="layer"></div>
            </div>
        </div>
        <span data-tooltip="${tooltip}">${label}</span>
        <i class="info fa fa-question-circle"></i>
    </div>`);

    $optionElement.find(".checkbox").prop("checked", checked).click(function () {
        Settings[name] = this.checked;
        setSettings(Settings);
        chrome.storage.sync.set({ config: Settings });
    });

    const $label = $optionElement.find("span[data-tooltip]");
    $optionElement.find(".info").on("mouseover", function () {
        $label.addClass("hover");
    }).on("mouseout", function () {
        $label.removeClass("hover");
    });

    $(".options").append($optionElement);

    $optionElements.push($optionElement);
}

function addStatus(name) {
    const $statusElement = $(`<div class="status" id="${name}">
        <div class="status-dot"></div>
        <span>${name}</span>
    </div>`);

    $(".statuses").append($statusElement);

    $statusElements.push($statusElement);
}


//Reload button to reload extension when enabled in html
$(".reload-button").click(() => {
    send("reload_window").then(() => {
        chrome.runtime.reload();
    });
});

//Shortcut to mapgenie homepage
$(".mapgenie-button").click(() => {
    chrome.tabs.create({ url: "https://mapgenie.io" });
});

//Closes the extension
$(".close-button").click(window.close.bind(window));

//Add options
for (let option of getOptions()) {
    addCheckboxOption(option.name, option.label, option.default, option.tooltip);
}

//Add status elements
addStatus("map");
addStatus("guide");
send("get_status").then(setStatus);

//Map data buttons to extract, import or clear data;
assignButton("button#export", "export_mapdata");
assignButton("button#import", "import_mapdata");
assignButton("button#clear", "clear_mapdata");

//Set extension info at the footer
$("#version").text(`v${chrome.runtime.getManifest().version}`);
$("#author").text(`by ${chrome.runtime.getManifest().author || "me"}`);
$("#author").click(() => {
    chrome.tabs.create({ url: "https://github.com/MrFusiion/MapGenieProUnlock" });
});

getSettings().then(settings => {
    Settings = settings;
    for (let $optionElement of $optionElements) {
        let type = $optionElement.attr("type");
        if (type === "checkbox") {
            let $input = $optionElement.find("input");
            $input.prop("checked", settings[$input.attr("id")]);
        }
    }
});
},{"../shared/settings":3}],3:[function(require,module,exports){
const options = Object.freeze(require("../options"));

//Gets all options
function getOptions() {
    return options;
}

//Gets stored extension settings
function getSettings() {
    return new Promise(resolve => {
        chrome.storage.sync.get(["config"], (result) => {
            let config = Object.assign({}, ...getOptions().map((option) => ({ [option.name]: option.default })), result.config || {});

            //Cleanup faulty keys
            for (let key in config) {
                if (key.match(/^\d+$/)) {
                    delete config[key];
                }
            }

            setSettings(config);
            resolve(config);
        });
    });
}

//Sets stored extension settings
function setSettings(settings) {
    chrome.storage.sync.set({ config: settings });
}


module.exports = { getOptions, getSettings, setSettings };
},{"../options":1}]},{},[2]);
